<template>
  <div>
    <p>个人中心</p>
    <Footers :active="3"></Footers>
  </div>
</template>

<script>
import Footers from '@/component/footer'

export default {
  

  data() {
    return {
    }
  },
	components: {
  	Footers
  },
  computed: {
  },

  methods: {
    
  }
};
</script>

<style lang="less">

</style>
